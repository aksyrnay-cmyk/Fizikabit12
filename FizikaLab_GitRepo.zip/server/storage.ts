import { type LabResult, type QuizResult } from "@shared/schema";

export interface IStorage {
  // Lab results storage methods
  getLabResults(labNumber: 7 | 8): Promise<LabResult[]>;
  saveLabResult(result: LabResult): Promise<LabResult>;
  
  // Quiz results storage methods
  getQuizResults(labNumber: 7 | 8): Promise<QuizResult[]>;
  saveQuizResult(result: QuizResult): Promise<QuizResult>;
}

export class MemStorage implements IStorage {
  private labResults: Map<string, LabResult>;
  private quizResults: Map<string, QuizResult>;

  constructor() {
    this.labResults = new Map();
    this.quizResults = new Map();
  }

  async getLabResults(labNumber: 7 | 8): Promise<LabResult[]> {
    return Array.from(this.labResults.values()).filter(
      (result) => result.labNumber === labNumber
    );
  }

  async saveLabResult(result: LabResult): Promise<LabResult> {
    this.labResults.set(result.id, result);
    return result;
  }

  async getQuizResults(labNumber: 7 | 8): Promise<QuizResult[]> {
    return Array.from(this.quizResults.values()).filter(
      (result) => result.labNumber === labNumber
    );
  }

  async saveQuizResult(result: QuizResult): Promise<QuizResult> {
    this.quizResults.set(result.id, result);
    return result;
  }
}

export const storage = new MemStorage();
