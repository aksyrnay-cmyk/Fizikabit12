# Design Guidelines: Interactive Physics Laboratory Platform

## Design Approach
**Educational Interactive System** - Following Material Design principles for educational applications with enhanced interactivity. Drawing inspiration from Khan Academy's clear instructional design and Brilliant.org's interactive learning experiences.

## Layout System
**Spacing Units**: Use Tailwind units of 4, 6, 8, 12, and 16 for consistent rhythm
- Page padding: px-6 md:px-12 lg:px-16
- Section spacing: py-12 md:py-16
- Component gaps: gap-4 to gap-8
- Container max-width: max-w-7xl for content areas

## Typography Hierarchy
**Google Fonts**: 
- Primary: Inter (UI elements, body text) - weights 400, 500, 600, 700
- Secondary: JetBrains Mono (formulas, calculations, technical data) - weights 400, 600

**Scale**:
- Page titles: text-4xl md:text-5xl font-bold
- Section headers: text-2xl md:text-3xl font-semibold
- Card titles: text-xl font-semibold
- Body text: text-base leading-relaxed
- Technical labels: text-sm font-mono
- Formulas: text-lg font-mono

## Color Palette (User-Specified)
- **Primary Blue** (Electricity): Main interactive elements, electric current visualizations
- **Energy Red**: Power indicators, energy flow animations, active states
- **Technical Grey**: Background sections, neutral elements, measurement displays
- **Success Green**: Correct answers, completed tasks
- **Warning Yellow**: Alerts, important notices

## Component Library

### Navigation Cards (Index Page)
- Grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Card structure: Rounded corners (rounded-xl), shadow-lg, hover:shadow-2xl transition
- Icon area at top (96x96px), title, brief description, arrow indicator
- Entrance animation: Staggered fade-in with slide-up effect

### Interactive Simulation Canvas
- **Electric Circuit Builder** (Lab 7):
  - Draggable components: Battery, ammeter, voltmeter, heating lamp, switch
  - Drop zones with visual feedback (dashed borders → solid when valid)
  - Wire connections: Animated SVG paths showing current flow
  - Measurement displays: Digital-style readouts with glowing effects when active
  
- **Magnetic Field Visualizer** (Lab 8):
  - SVG-based magnetic field lines with smooth curves
  - Iron filings particle system using Canvas API
  - Draggable magnet shapes (bar, horseshoe) with rotation handles
  - Material testing area with attraction/repulsion animations

### Theory Content Layout
- Two-column layout on desktop: sticky sidebar navigation + scrollable content
- Formula boxes: Centered, larger mono font, subtle background, padding-6
- Diagram integration: Float right on desktop with text wrap, full-width on mobile
- Key concepts: Highlighted boxes with left border accent

### Lab Work Instructions
- Step-by-step accordion: Expandable panels with numbered steps
- Progress indicator: Vertical timeline on left showing completion
- Interactive checkboxes: Confirm each step before proceeding
- Auto-calculating tables: Input fields with real-time formula results
- Data persistence: Local storage save/load with visual confirmation

### Quiz Interface
- Question cards: One per screen, large, centered
- Multiple choice: Radio buttons styled as cards (hover effects, selected state with checkmark)
- Instant feedback: Green/red color coding, explanation reveals
- Progress bar: Top of screen showing question number and score
- Results dashboard: Pie chart visualization, score percentage, topic breakdown

## Interactive Elements & Animations

**Page Transitions**: Smooth fade (300ms) between sections
**Component Reveals**: Intersection Observer triggers for scroll-based animations
**Drag & Drop**: Visual lift effect (translateY(-4px), shadow increase), snap-to-grid alignment
**Circuit Activation**: Current flow animation using SVG stroke-dasharray, lamp brightness fade-in
**Magnetic Field**: Real-time redraw on interaction, particle physics for iron filings (60fps)
**Form Calculations**: Number inputs → debounced calculation (300ms) → animated result update

## Icons
**Heroicons** (CDN) for UI elements:
- Navigation: arrow-right, chevron-down
- Actions: play, pause, refresh, save, download
- Status: check-circle, x-circle, exclamation
- Custom physics icons as inline SVG: circuit symbols, magnet shapes

## Images
**Hero Section (Index)**: Full-width split hero - left side with abstract circuit board pattern, right side with magnetic field visualization (1920x800px)
**Section Headers**: Small illustrative diagrams (400x300px) - circuit diagrams for Lab 7, magnet field patterns for Lab 8
**Theory Diagrams**: Technical illustrations showing electrical components and magnetic field configurations

## Responsive Behavior
- **Mobile** (<768px): Single column, stacked cards, simplified simulations with touch gestures
- **Tablet** (768-1024px): Two-column grids, side-by-side theory/practice views
- **Desktop** (>1024px): Full multi-column layouts, enhanced hover interactions, larger canvas areas

## Accessibility
- ARIA labels for all interactive simulations
- Keyboard navigation for all drag-drop operations (arrow keys + enter)
- High contrast mode support for formulas and diagrams
- Focus indicators on all interactive elements (2px outline with offset)
- Kazakh language throughout interface