import { z } from "zod";

export interface QuizQuestion {
  id: string;
  labNumber: 7 | 8;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface LabResult {
  id: string;
  labNumber: 7 | 8;
  timestamp: number;
  current?: number;
  voltage?: number;
  time?: number;
  power?: number;
  work?: number;
  materialName?: string;
  attracted?: boolean;
  notes?: string;
}

export interface QuizResult {
  id: string;
  labNumber: 7 | 8;
  timestamp: number;
  score: number;
  totalQuestions: number;
  answers: {
    questionId: string;
    selectedAnswer: number;
    correct: boolean;
  }[];
}

export const labResultSchema = z.object({
  labNumber: z.union([z.literal(7), z.literal(8)]),
  current: z.number().optional(),
  voltage: z.number().optional(),
  time: z.number().optional(),
  power: z.number().optional(),
  work: z.number().optional(),
  materialName: z.string().optional(),
  attracted: z.boolean().optional(),
  notes: z.string().optional(),
});

export const quizAnswerSchema = z.object({
  labNumber: z.union([z.literal(7), z.literal(8)]),
  answers: z.array(z.object({
    questionId: z.string(),
    selectedAnswer: z.number(),
  })),
});

export type InsertLabResult = z.infer<typeof labResultSchema>;
export type InsertQuizAnswer = z.infer<typeof quizAnswerSchema>;
