import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Zap, Magnet, RotateCcw, Play } from "lucide-react";
import ElectricCircuitSimulation from "@/components/simulations/electric-circuit";
import MagneticFieldSimulation from "@/components/simulations/magnetic-field";

export default function Simulation() {
  const [activeTab, setActiveTab] = useState<string>("lab7");

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-r from-primary/10 to-energy/10 border-b border-border">
        <div className="container mx-auto px-6 md:px-12 lg:px-16 py-8">
          <div className="flex items-center gap-4 mb-6">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                Интерактивті симуляциялар
              </h1>
              <p className="text-muted-foreground mt-2">
                Виртуалды тәжірибелер және визуализациялар
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 md:px-12 lg:px-16 py-12">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-2 mb-12">
            <TabsTrigger value="lab7" className="gap-2" data-testid="tab-lab7">
              <Zap className="w-4 h-4" />
              7-зертхана: Электр тізбегі
            </TabsTrigger>
            <TabsTrigger value="lab8" className="gap-2" data-testid="tab-lab8">
              <Magnet className="w-4 h-4" />
              8-зертхана: Магнит өрісі
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lab7" className="space-y-6">
            <Card className="p-6 bg-primary/5 border-primary/20">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-foreground">
                    Электр тізбегін жинау
                  </h2>
                  <p className="text-muted-foreground">
                    Элементтерді сүйреп апарып тізбекті құрастырыңыз
                  </p>
                </div>
              </div>
              
              <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-6">
                <p className="text-sm text-foreground">
                  <strong>Нұсқаулық:</strong> Электр тізбегінің элементтерін сүйреп апарып (Drag & Drop) 
                  тізбекті құрастырыңыз. Кернеу мен ток күшін өзгертіп, қуат пен жұмыстың есебін көріңіз.
                </p>
              </div>
            </Card>

            <ElectricCircuitSimulation />
          </TabsContent>

          <TabsContent value="lab8" className="space-y-6">
            <Card className="p-6 bg-energy/5 border-energy/20">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 rounded-lg bg-energy/10">
                  <Magnet className="w-6 h-6 text-energy" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-foreground">
                    Магнит өрісін зерттеу
                  </h2>
                  <p className="text-muted-foreground">
                    Магнитті қозғалтып, өріс сызықтарын бақылаңыз
                  </p>
                </div>
              </div>
              
              <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-6">
                <p className="text-sm text-foreground">
                  <strong>Нұсқаулық:</strong> Магнитті сүйреп қозғалтыңыз. Әртүрлі материалдарды 
                  магнитке жақындатып, олардың тартылу/тартылмау қасиеттерін бақылаңыз.
                </p>
              </div>
            </Card>

            <MagneticFieldSimulation />
          </TabsContent>
        </Tabs>

        <div className="mt-12 flex flex-wrap justify-center gap-4">
          <Link href="/theory">
            <Button variant="outline" size="lg" data-testid="button-to-theory">
              Теорияға қайту
            </Button>
          </Link>
          <Link href="/lab-work">
            <Button variant="default" size="lg" data-testid="button-to-lab-work">
              Зертханалық жұмысқа өту
              <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
