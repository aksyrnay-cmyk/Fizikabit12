import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, FlaskConical, GraduationCap, Brain, Zap, Magnet } from "lucide-react";
import { useEffect, useRef } from "react";

export default function Home() {
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, index) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add("opacity-100", "translate-y-0");
            }, index * 100);
          }
        });
      },
      { threshold: 0.1 }
    );

    cardsRef.current.forEach((card) => {
      if (card) observer.observe(card);
    });

    return () => observer.disconnect();
  }, []);

  const navigationCards = [
    {
      icon: BookOpen,
      title: "Теориялық материалдар",
      description: "Электр тогының жұмысы мен қуаты, магниттік өрістер туралы толық ақпарат",
      path: "/theory",
      color: "primary",
      testId: "card-theory",
    },
    {
      icon: FlaskConical,
      title: "Интерактивті симуляциялар",
      description: "Виртуалды тәжірибелер: электр тізбектері мен магнит өрістерін зерттеу",
      path: "/simulation",
      color: "energy",
      testId: "card-simulation",
    },
    {
      icon: GraduationCap,
      title: "Зертханалық жұмыстар",
      description: "Қадамдық нұсқаулар мен есептеу кестелері",
      path: "/lab-work",
      color: "success",
      testId: "card-lab-work",
    },
    {
      icon: Brain,
      title: "Білімді тексеру",
      description: "Тест сұрақтары және интерактивті тапсырмалар",
      path: "/quiz",
      color: "warning",
      testId: "card-quiz",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-energy/10">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iY3VycmVudENvbG9yIiBzdHJva2Utb3BhY2l0eT0iMC4wNSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-40" />
        
        <div className="container mx-auto px-6 md:px-12 lg:px-16 py-16 md:py-24 relative z-10">
          <div className="text-center space-y-6 mb-16">
            <div className="inline-flex items-center gap-3 mb-4">
              <div className="p-3 rounded-xl bg-primary/10">
                <Zap className="w-8 h-8 text-primary" />
              </div>
              <div className="p-3 rounded-xl bg-energy/10">
                <Magnet className="w-8 h-8 text-energy" />
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground">
              Физика Зертханасы
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Интерактивті оқу платформасы
            </p>
            
            <div className="flex flex-wrap gap-4 justify-center mt-8">
              <div className="px-6 py-3 rounded-xl bg-card border border-card-border">
                <p className="text-sm text-muted-foreground">7-зертхана</p>
                <p className="font-semibold text-foreground">Электр тогының жұмысы мен қуаты</p>
              </div>
              <div className="px-6 py-3 rounded-xl bg-card border border-card-border">
                <p className="text-sm text-muted-foreground">8-зертхана</p>
                <p className="font-semibold text-foreground">Тұрақты магниттің қасиеттері</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-6xl mx-auto">
            {navigationCards.map((card, index) => {
              const Icon = card.icon;
              const colorClass = {
                primary: "from-primary/20 to-primary/5",
                energy: "from-energy/20 to-energy/5",
                success: "from-success/20 to-success/5",
                warning: "from-warning/20 to-warning/5",
              }[card.color];

              const iconColorClass = {
                primary: "text-primary",
                energy: "text-energy",
                success: "text-success",
                warning: "text-warning",
              }[card.color];

              return (
                <div
                  key={index}
                  ref={(el) => (cardsRef.current[index] = el)}
                  className="opacity-0 translate-y-8 transition-all duration-700"
                  data-testid={card.testId}
                >
                  <Link href={card.path}>
                    <Card className={`p-8 cursor-pointer border-2 hover-elevate active-elevate-2 h-full bg-gradient-to-br ${colorClass} transition-all duration-300`}>
                      <div className="flex flex-col gap-6">
                        <div className={`p-4 rounded-xl bg-background/50 w-fit`}>
                          <Icon className={`w-12 h-12 ${iconColorClass}`} />
                        </div>
                        
                        <div className="space-y-3">
                          <h3 className="text-2xl font-semibold text-foreground">
                            {card.title}
                          </h3>
                          <p className="text-muted-foreground leading-relaxed">
                            {card.description}
                          </p>
                        </div>

                        <Button 
                          variant="ghost" 
                          className="w-fit mt-auto group"
                          data-testid={`button-${card.testId}`}
                        >
                          Ашу
                          <svg 
                            className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" 
                            fill="none" 
                            stroke="currentColor" 
                            viewBox="0 0 24 24"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                          </svg>
                        </Button>
                      </div>
                    </Card>
                  </Link>
                </div>
              );
            })}
          </div>

          <div className="mt-16 text-center">
            <p className="text-muted-foreground">
              7-сынып және 8-сынып физика бағдарламасына сәйкес
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
