import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Zap, Magnet, Lightbulb, Atom } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function Theory() {
  const [activeTab, setActiveTab] = useState<string>("lab7");

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-r from-primary/10 to-energy/10 border-b border-border">
        <div className="container mx-auto px-6 md:px-12 lg:px-16 py-8">
          <div className="flex items-center gap-4 mb-6">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                Теориялық материалдар
              </h1>
              <p className="text-muted-foreground mt-2">
                Зертханалық жұмыстардың негізгі ұғымдары мен заңдары
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 md:px-12 lg:px-16 py-12">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-2 mb-12">
            <TabsTrigger value="lab7" className="gap-2" data-testid="tab-lab7">
              <Zap className="w-4 h-4" />
              7-зертхана
            </TabsTrigger>
            <TabsTrigger value="lab8" className="gap-2" data-testid="tab-lab8">
              <Magnet className="w-4 h-4" />
              8-зертхана
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lab7" className="space-y-8">
            <Card className="p-8 md:p-12">
              <div className="flex items-center gap-4 mb-8">
                <div className="p-4 rounded-xl bg-primary/10">
                  <Zap className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-foreground">
                    Электр тогының жұмысы мен қуаты
                  </h2>
                  <p className="text-muted-foreground mt-1">7-зертханалық жұмыс</p>
                </div>
              </div>

              <div className="space-y-8">
                <section>
                  <h3 className="text-2xl font-semibold text-foreground mb-4 flex items-center gap-3">
                    <Lightbulb className="w-6 h-6 text-warning" />
                    Электр тогының жұмысы
                  </h3>
                  <p className="text-foreground leading-relaxed mb-4">
                    Электр тогының жұмысы деп электр өрісінің зарядты орын ауыстыру кезінде 
                    атқаратын жұмысын айтамыз. Электр тогының жұмысы өткізгіштегі кернеуге, 
                    токқа және оның өту уақытына тікелей пропорционал.
                  </p>
                  
                  <Card className="p-6 bg-primary/5 border-primary/20 my-6">
                    <p className="text-center text-2xl font-mono font-semibold text-primary mb-2">
                      A = I · U · t
                    </p>
                    <div className="text-sm text-muted-foreground text-center space-y-1">
                      <p>A - жұмыс (Джоуль, Дж)</p>
                      <p>I - ток күші (Ампер, А)</p>
                      <p>U - кернеу (Вольт, В)</p>
                      <p>t - уақыт (секунд, с)</p>
                    </div>
                  </Card>

                  <p className="text-foreground leading-relaxed">
                    Электр тогының жұмысы Джоульмен (Дж) өлшенеді. 1 Джоуль - бұл 1 Ампер 
                    ток күші 1 Вольт кернеу кезінде 1 секунд ішінде атқаратын жұмыс.
                  </p>
                </section>

                <Separator />

                <section>
                  <h3 className="text-2xl font-semibold text-foreground mb-4 flex items-center gap-3">
                    <Atom className="w-6 h-6 text-energy" />
                    Электр тогының қуаты
                  </h3>
                  <p className="text-foreground leading-relaxed mb-4">
                    Электр тогының қуаты деп уақыт бірлігінде атқарылатын жұмысты айтамыз. 
                    Қуат өткізгіштегі ток күші мен кернеудің көбейтіндісіне тең.
                  </p>

                  <Card className="p-6 bg-energy/5 border-energy/20 my-6">
                    <p className="text-center text-2xl font-mono font-semibold text-energy mb-2">
                      P = I · U = A / t
                    </p>
                    <div className="text-sm text-muted-foreground text-center space-y-1">
                      <p>P - қуат (Ватт, Вт)</p>
                      <p>I - ток күші (Ампер, А)</p>
                      <p>U - кернеу (Вольт, В)</p>
                      <p>A - жұмыс (Джоуль, Дж)</p>
                      <p>t - уақыт (секунд, с)</p>
                    </div>
                  </Card>

                  <p className="text-foreground leading-relaxed">
                    Электр тогының қуаты Ваттпен (Вт) өлшенеді. 1 Ватт - бұл 1 Ампер ток 
                    күші 1 Вольт кернеу кезіндегі қуат.
                  </p>
                </section>

                <Separator />

                <section>
                  <h3 className="text-2xl font-semibold text-foreground mb-4">
                    Өткізгіштердің жалғанулары
                  </h3>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <Card className="p-6 bg-card">
                      <h4 className="font-semibold text-lg text-foreground mb-3">
                        Тізбектей жалғау
                      </h4>
                      <ul className="space-y-2 text-foreground list-disc list-inside">
                        <li>Ток күші барлық жерде бірдей: I = I₁ = I₂</li>
                        <li>Толық кернеу: U = U₁ + U₂</li>
                        <li>Толық кедергі: R = R₁ + R₂</li>
                      </ul>
                    </Card>

                    <Card className="p-6 bg-card">
                      <h4 className="font-semibold text-lg text-foreground mb-3">
                        Параллель жалғау
                      </h4>
                      <ul className="space-y-2 text-foreground list-disc list-inside">
                        <li>Кернеу барлық жерде бірдей: U = U₁ = U₂</li>
                        <li>Толық ток: I = I₁ + I₂</li>
                        <li>Кедергі: 1/R = 1/R₁ + 1/R₂</li>
                      </ul>
                    </Card>
                  </div>
                </section>

                <section className="bg-success/5 p-6 rounded-xl border border-success/20">
                  <h4 className="font-semibold text-lg text-foreground mb-3 flex items-center gap-2">
                    <span className="text-success">✓</span>
                    Маңызды ескертулер
                  </h4>
                  <ul className="space-y-2 text-foreground">
                    <li>• Электр тогының жұмысы энергияның түрлену заңына бағынады</li>
                    <li>• Қуат жұмысты тез орындау қабілетін көрсетеді</li>
                    <li>• Өлшеу аспаптары: амперметр (ток), вольтметр (кернеу)</li>
                  </ul>
                </section>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="lab8" className="space-y-8">
            <Card className="p-8 md:p-12">
              <div className="flex items-center gap-4 mb-8">
                <div className="p-4 rounded-xl bg-energy/10">
                  <Magnet className="w-8 h-8 text-energy" />
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-foreground">
                    Тұрақты магниттің қасиеттері
                  </h2>
                  <p className="text-muted-foreground mt-1">8-зертханалық жұмыс</p>
                </div>
              </div>

              <div className="space-y-8">
                <section>
                  <h3 className="text-2xl font-semibold text-foreground mb-4">
                    Магнит өрісі
                  </h3>
                  <p className="text-foreground leading-relaxed mb-4">
                    Магнит өрісі - магниттердің және қозғалатын зарядталған бөлшектердің 
                    айналасында пайда болатын материяның ерекше түрі. Магнит өрісі басқа 
                    магниттер мен темір заттарға әсер етеді.
                  </p>

                  <Card className="p-6 bg-energy/5 border-energy/20 my-6">
                    <h4 className="font-semibold text-lg text-foreground mb-4 text-center">
                      Магнит өрісінің қасиеттері
                    </h4>
                    <ul className="space-y-3 text-foreground">
                      <li className="flex items-start gap-3">
                        <span className="text-energy font-bold">1.</span>
                        <span>Магнит өрісі көзге көрінбейді, бірақ оның әсерін байқауға болады</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-energy font-bold">2.</span>
                        <span>Магнит өрісі кеңістікте таралады және заттар арқылы өтеді</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-energy font-bold">3.</span>
                        <span>Магнит өрісінің бағыты магнит тілшесінің солтүстік полюсімен анықталады</span>
                      </li>
                    </ul>
                  </Card>
                </section>

                <Separator />

                <section>
                  <h3 className="text-2xl font-semibold text-foreground mb-4">
                    Тұрақты магниттер
                  </h3>
                  <p className="text-foreground leading-relaxed mb-4">
                    Тұрақты магнит - магниттік қасиеттері ұзақ уақыт сақталатын дене. 
                    Әрбір магнитте екі полюс болады: солтүстік (N) және оңтүстік (S).
                  </p>

                  <div className="grid md:grid-cols-2 gap-6 my-6">
                    <Card className="p-6 bg-card">
                      <h4 className="font-semibold text-lg text-foreground mb-3 text-center">
                        Магниттердің өзара әрекеттесуі
                      </h4>
                      <div className="space-y-3 text-foreground">
                        <div className="p-3 bg-success/10 rounded-md border border-success/20">
                          <p className="font-medium">Әртүрлі полюстер:</p>
                          <p className="text-sm">N ↔ S - тартылады</p>
                        </div>
                        <div className="p-3 bg-destructive/10 rounded-md border border-destructive/20">
                          <p className="font-medium">Бірдей полюстер:</p>
                          <p className="text-sm">N ↔ N немесе S ↔ S - тебіледі</p>
                        </div>
                      </div>
                    </Card>

                    <Card className="p-6 bg-card">
                      <h4 className="font-semibold text-lg text-foreground mb-3 text-center">
                        Магнит пішіндері
                      </h4>
                      <ul className="space-y-2 text-foreground">
                        <li>• Жолақ тәрізді магнит</li>
                        <li>• Доға тәрізді (тағалы) магнит</li>
                        <li>• Дөңгелек магнит</li>
                        <li>• Цилиндр тәрізді магнит</li>
                      </ul>
                    </Card>
                  </div>
                </section>

                <Separator />

                <section>
                  <h3 className="text-2xl font-semibold text-foreground mb-4">
                    Магниттік материалдар
                  </h3>
                  
                  <div className="space-y-4">
                    <Card className="p-6 bg-primary/5 border-primary/20">
                      <h4 className="font-semibold text-lg text-foreground mb-3">
                        Ферромагниттер (магнитке тартылатын)
                      </h4>
                      <p className="text-foreground mb-3">
                        Күшті магниттік қасиеттері бар заттар. Магниттелуге оңай.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Мысалдар: темір, никель, кобальт, болат
                      </p>
                    </Card>

                    <Card className="p-6 bg-muted/50 border-muted">
                      <h4 className="font-semibold text-lg text-foreground mb-3">
                        Парамагниттер (әлсіз тартылатын)
                      </h4>
                      <p className="text-foreground mb-3">
                        Магнитке әлсіз тартылатын заттар.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Мысалдар: алюминий, платина, оттегі
                      </p>
                    </Card>

                    <Card className="p-6 bg-muted/50 border-muted">
                      <h4 className="font-semibold text-lg text-foreground mb-3">
                        Диамагниттер (тартылмайтын)
                      </h4>
                      <p className="text-foreground mb-3">
                        Магниттен итерілетін заттар. Магниттік қасиеттері жоқ.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Мысалдар: мыс, күміс, алтын, пластик, ағаш, қағаз
                      </p>
                    </Card>
                  </div>
                </section>

                <section className="bg-warning/5 p-6 rounded-xl border border-warning/20">
                  <h4 className="font-semibold text-lg text-foreground mb-3 flex items-center gap-2">
                    <span className="text-warning">⚠</span>
                    Маңызды ескертулер
                  </h4>
                  <ul className="space-y-2 text-foreground">
                    <li>• Магнитті құлатып немесе қыздырып жіберсе, магниттік қасиеті әлсіреуі мүмкін</li>
                    <li>• Магнит өрісін темір ұнтағымен көрнекі түрде көрсетуге болады</li>
                    <li>• Магнит өрісі полюстерде ең күшті болады</li>
                    <li>• Жердің өзі үлкен магнит болып табылады</li>
                  </ul>
                </section>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-12 flex justify-center gap-4">
          <Link href="/simulation">
            <Button variant="default" size="lg" data-testid="button-to-simulation">
              Симуляцияларға өту
              <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
