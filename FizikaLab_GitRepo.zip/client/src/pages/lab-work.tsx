import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Zap, Magnet, Save, Download } from "lucide-react";
import Lab7Instructions from "@/components/lab-instructions/lab7-instructions";
import Lab8Instructions from "@/components/lab-instructions/lab8-instructions";

export default function LabWork() {
  const [activeTab, setActiveTab] = useState<string>("lab7");

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-r from-success/10 to-primary/10 border-b border-border">
        <div className="container mx-auto px-6 md:px-12 lg:px-16 py-8">
          <div className="flex items-center gap-4 mb-6">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                Зертханалық жұмыстар
              </h1>
              <p className="text-muted-foreground mt-2">
                Қадамдық нұсқаулар мен есептеу кестелері
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 md:px-12 lg:px-16 py-12">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-2 mb-12">
            <TabsTrigger value="lab7" className="gap-2" data-testid="tab-lab7">
              <Zap className="w-4 h-4" />
              7-зертхана
            </TabsTrigger>
            <TabsTrigger value="lab8" className="gap-2" data-testid="tab-lab8">
              <Magnet className="w-4 h-4" />
              8-зертхана
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lab7">
            <Lab7Instructions />
          </TabsContent>

          <TabsContent value="lab8">
            <Lab8Instructions />
          </TabsContent>
        </Tabs>

        <div className="mt-12 flex flex-wrap justify-center gap-4">
          <Link href="/simulation">
            <Button variant="outline" size="lg" data-testid="button-to-simulation">
              Симуляцияларға қайту
            </Button>
          </Link>
          <Link href="/quiz">
            <Button variant="default" size="lg" data-testid="button-to-quiz">
              Білімді тексеруге өту
              <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
