import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Save, Trash2, Zap, CheckCircle } from "lucide-react";
import type { LabResult } from "@shared/schema";

interface Measurement {
  id: string;
  current: number;
  voltage: number;
  time: number;
  power: number;
  work: number;
}

export default function Lab7Instructions() {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [notes, setNotes] = useState<string>("");

  const steps = [
    "Қажетті құрал-жабдықтарды дайындаңыз: ток көзі, амперметр, вольтметр, қыздыру шамы, кілт, өткізгіш сымдар",
    "Электр тізбегін жинаңыз: ток көзін амперметр арқылы қыздыру шамасына жалғаңыз",
    "Вольтметрді қыздыру шамасына параллель жалғаңыз",
    "Тізбекті тексеріп, барлық қосылыстардың дұрыстығын анықтаңыз",
    "Кілтті жауып, тізбекті іске қосыңыз",
    "Амперметрдің көрсеткішін (I) жазып алыңыз",
    "Вольтметрдің көрсеткішін (U) жазып алыңыз",
    "Уақытты (t) өлшеңіз және P = I·U, A = P·t формулалары бойынша есептеулер жүргізіңіз",
    "Алынған мәліметтерді кестеге жазыңыз",
    "Қорытынды жасаңыз және нәтижелерді сақтаңыз"
  ];

  const toggleStep = (index: number) => {
    const newCompleted = new Set(completedSteps);
    if (newCompleted.has(index)) {
      newCompleted.delete(index);
    } else {
      newCompleted.add(index);
    }
    setCompletedSteps(newCompleted);
  };

  const addMeasurement = () => {
    const newMeasurement: Measurement = {
      id: Date.now().toString(),
      current: 0,
      voltage: 0,
      time: 0,
      power: 0,
      work: 0,
    };
    setMeasurements([...measurements, newMeasurement]);
  };

  const updateMeasurement = (id: string, field: keyof Measurement, value: number) => {
    setMeasurements(measurements.map(m => {
      if (m.id === id) {
        const updated = { ...m, [field]: value };
        updated.power = updated.current * updated.voltage;
        updated.work = updated.power * updated.time;
        return updated;
      }
      return m;
    }));
  };

  const deleteMeasurement = (id: string) => {
    setMeasurements(measurements.filter(m => m.id !== id));
  };

  const saveResults = () => {
    const results: LabResult[] = measurements.map(m => ({
      id: m.id,
      labNumber: 7,
      timestamp: Date.now(),
      current: m.current,
      voltage: m.voltage,
      time: m.time,
      power: m.power,
      work: m.work,
      notes: notes,
    }));

    localStorage.setItem("lab7-results", JSON.stringify(results));
    localStorage.setItem("lab7-notes", notes);
    
    toast({
      title: "Нәтижелер сақталды",
      description: `${measurements.length} өлшем сәтті сақталды`,
    });
  };

  useEffect(() => {
    const savedResults = localStorage.getItem("lab7-results");
    const savedNotes = localStorage.getItem("lab7-notes");
    
    if (savedResults) {
      const results = JSON.parse(savedResults) as LabResult[];
      const loadedMeasurements: Measurement[] = results.map(r => ({
        id: r.id,
        current: r.current || 0,
        voltage: r.voltage || 0,
        time: r.time || 0,
        power: r.power || 0,
        work: r.work || 0,
      }));
      setMeasurements(loadedMeasurements);
    }
    
    if (savedNotes) {
      setNotes(savedNotes);
    }
  }, []);

  const progress = (completedSteps.size / steps.length) * 100;

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-primary/5 border-primary/20">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-lg bg-primary/10">
            <Zap className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-foreground">
              Электр тогының жұмысы мен қуаты
            </h2>
            <p className="text-muted-foreground">
              7-зертханалық жұмыс
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Орындалуы: {completedSteps.size} / {steps.length}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-6 text-xl">
          Қадамдық нұсқаулар
        </h3>

        <div className="space-y-4">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`flex items-start gap-4 p-4 rounded-lg border transition-all ${
                completedSteps.has(index)
                  ? "bg-success/5 border-success/20"
                  : "bg-card border-card-border hover-elevate"
              }`}
              data-testid={`step-${index}`}
            >
              <Checkbox
                checked={completedSteps.has(index)}
                onCheckedChange={() => toggleStep(index)}
                className="mt-1"
                data-testid={`checkbox-step-${index}`}
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`font-semibold ${
                    completedSteps.has(index) ? "text-success" : "text-primary"
                  }`}>
                    {index + 1}-қадам
                  </span>
                  {completedSteps.has(index) && (
                    <CheckCircle className="w-4 h-4 text-success" />
                  )}
                </div>
                <p className="text-foreground leading-relaxed">{step}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-foreground text-xl">
            Өлшеу нәтижелері
          </h3>
          <Button
            onClick={addMeasurement}
            variant="default"
            size="sm"
            data-testid="button-add-measurement"
          >
            Өлшем қосу
          </Button>
        </div>

        <div className="space-y-4">
          {measurements.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>Өлшемдер әлі қосылмаған</p>
              <p className="text-sm mt-2">«Өлшем қосу» батырмасын басыңыз</p>
            </div>
          ) : (
            measurements.map((measurement, index) => (
              <Card key={measurement.id} className="p-6 bg-muted/30" data-testid={`measurement-${index}`}>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-foreground">
                    Өлшем #{index + 1}
                  </h4>
                  <Button
                    onClick={() => deleteMeasurement(measurement.id)}
                    variant="ghost"
                    size="icon"
                    data-testid={`button-delete-${index}`}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>

                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="space-y-2">
                    <Label>Ток күші (I), А</Label>
                    <Input
                      type="number"
                      value={measurement.current}
                      onChange={(e) => updateMeasurement(measurement.id, "current", Number(e.target.value))}
                      min="0"
                      step="0.01"
                      className="font-mono"
                      data-testid={`input-current-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Кернеу (U), В</Label>
                    <Input
                      type="number"
                      value={measurement.voltage}
                      onChange={(e) => updateMeasurement(measurement.id, "voltage", Number(e.target.value))}
                      min="0"
                      step="0.01"
                      className="font-mono"
                      data-testid={`input-voltage-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Уақыт (t), с</Label>
                    <Input
                      type="number"
                      value={measurement.time}
                      onChange={(e) => updateMeasurement(measurement.id, "time", Number(e.target.value))}
                      min="0"
                      step="1"
                      className="font-mono"
                      data-testid={`input-time-${index}`}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mt-4 p-4 bg-background rounded-lg">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Қуат (P = I × U)</p>
                    <p className="text-2xl font-bold font-mono text-primary" data-testid={`text-power-${index}`}>
                      {measurement.power.toFixed(2)} Вт
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Жұмыс (A = P × t)</p>
                    <p className="text-2xl font-bold font-mono text-energy" data-testid={`text-work-${index}`}>
                      {measurement.work.toFixed(2)} Дж
                    </p>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4 text-xl">
          Қорытынды және ескертпелер
        </h3>
        <Textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Зертхана жұмысы туралы қорытынды жазыңыз..."
          className="min-h-[150px]"
          data-testid="textarea-notes"
        />
      </Card>

      <div className="flex justify-end gap-4">
        <Button
          onClick={saveResults}
          variant="default"
          size="lg"
          disabled={measurements.length === 0}
          data-testid="button-save-results"
        >
          <Save className="w-4 h-4 mr-2" />
          Нәтижелерді сақтау
        </Button>
      </div>
    </div>
  );
}
