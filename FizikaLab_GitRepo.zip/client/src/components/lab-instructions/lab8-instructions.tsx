import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Save, Trash2, Magnet, CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { LabResult } from "@shared/schema";

interface MaterialTest {
  id: string;
  materialName: string;
  attracted: boolean;
  notes: string;
}

export default function Lab8Instructions() {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [tests, setTests] = useState<MaterialTest[]>([]);
  const [generalNotes, setGeneralNotes] = useState<string>("");

  const steps = [
    "Қажетті құрал-жабдықтарды дайындаңыз: жолақ тәрізді магнит, әртүрлі материалдар (темір, мыс, алюминий, пластик, т.б.)",
    "Магниттің полюстерін анықтаңыз: магнит тілшесін немесе компасты пайдаланыңыз",
    "Темір материалды магнитке жақындатыңыз және тартылуын бақылаңыз",
    "Мыс материалды магнитке жақындатыңыз және әсерін байқаңыз",
    "Пластик материалды магнитке жақындатыңыз және әсерін байқаңыз",
    "Әр материал үшін нәтижелерді кестеге жазыңыз",
    "Магнит өрісін темір ұнтағымен көрсетіңіз",
    "Магнит өрісінің күшін полюстерде және ортасында салыстырыңыз",
    "Нәтижелерді талдаңыз және материалдарды топтарға бөліңіз",
    "Қорытынды жасаңыз және нәтижелерді сақтаңыз"
  ];

  const suggestedMaterials = [
    { name: "Темір", attracted: true },
    { name: "Болат", attracted: true },
    { name: "Никель", attracted: true },
    { name: "Кобальт", attracted: true },
    { name: "Мыс", attracted: false },
    { name: "Алюминий", attracted: false },
    { name: "Пластик", attracted: false },
    { name: "Ағаш", attracted: false },
    { name: "Қағаз", attracted: false },
    { name: "Шыны", attracted: false },
  ];

  const toggleStep = (index: number) => {
    const newCompleted = new Set(completedSteps);
    if (newCompleted.has(index)) {
      newCompleted.delete(index);
    } else {
      newCompleted.add(index);
    }
    setCompletedSteps(newCompleted);
  };

  const addTest = (materialName?: string, attracted?: boolean) => {
    const newTest: MaterialTest = {
      id: Date.now().toString(),
      materialName: materialName || "",
      attracted: attracted !== undefined ? attracted : false,
      notes: "",
    };
    setTests([...tests, newTest]);
  };

  const updateTest = (id: string, field: keyof MaterialTest, value: string | boolean) => {
    setTests(tests.map(t => t.id === id ? { ...t, [field]: value } : t));
  };

  const deleteTest = (id: string) => {
    setTests(tests.filter(t => t.id !== id));
  };

  const saveResults = () => {
    const results: LabResult[] = tests.map(t => ({
      id: t.id,
      labNumber: 8,
      timestamp: Date.now(),
      materialName: t.materialName,
      attracted: t.attracted,
      notes: `${t.notes}\n\n${generalNotes}`,
    }));

    localStorage.setItem("lab8-results", JSON.stringify(results));
    localStorage.setItem("lab8-notes", generalNotes);
    
    toast({
      title: "Нәтижелер сақталды",
      description: `${tests.length} тест сәтті сақталды`,
    });
  };

  useEffect(() => {
    const savedResults = localStorage.getItem("lab8-results");
    const savedNotes = localStorage.getItem("lab8-notes");
    
    if (savedResults) {
      const results = JSON.parse(savedResults) as LabResult[];
      const loadedTests: MaterialTest[] = results.map(r => ({
        id: r.id,
        materialName: r.materialName || "",
        attracted: r.attracted || false,
        notes: r.notes || "",
      }));
      setTests(loadedTests);
    }
    
    if (savedNotes) {
      setGeneralNotes(savedNotes);
    }
  }, []);

  const progress = (completedSteps.size / steps.length) * 100;

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-energy/5 border-energy/20">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-lg bg-energy/10">
            <Magnet className="w-6 h-6 text-energy" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-foreground">
              Тұрақты магниттің қасиеттері
            </h2>
            <p className="text-muted-foreground">
              8-зертханалық жұмыс
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Орындалуы: {completedSteps.size} / {steps.length}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-energy transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-6 text-xl">
          Қадамдық нұсқаулар
        </h3>

        <div className="space-y-4">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`flex items-start gap-4 p-4 rounded-lg border transition-all ${
                completedSteps.has(index)
                  ? "bg-success/5 border-success/20"
                  : "bg-card border-card-border hover-elevate"
              }`}
              data-testid={`step-${index}`}
            >
              <Checkbox
                checked={completedSteps.has(index)}
                onCheckedChange={() => toggleStep(index)}
                className="mt-1"
                data-testid={`checkbox-step-${index}`}
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`font-semibold ${
                    completedSteps.has(index) ? "text-success" : "text-energy"
                  }`}>
                    {index + 1}-қадам
                  </span>
                  {completedSteps.has(index) && (
                    <CheckCircle className="w-4 h-4 text-success" />
                  )}
                </div>
                <p className="text-foreground leading-relaxed">{step}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6 bg-warning/5 border-warning/20">
        <h3 className="font-semibold text-foreground mb-4 text-lg">
          Ұсынылатын материалдар
        </h3>
        <div className="flex flex-wrap gap-2">
          {suggestedMaterials.map((material) => (
            <Button
              key={material.name}
              onClick={() => addTest(material.name, material.attracted)}
              variant="outline"
              size="sm"
              className="gap-2"
              data-testid={`button-add-${material.name}`}
            >
              {material.name}
              <Badge variant={material.attracted ? "default" : "secondary"} className="text-xs">
                {material.attracted ? "+" : "-"}
              </Badge>
            </Button>
          ))}
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-foreground text-xl">
            Тест нәтижелері
          </h3>
          <Button
            onClick={() => addTest()}
            variant="default"
            size="sm"
            data-testid="button-add-test"
          >
            Тест қосу
          </Button>
        </div>

        <div className="space-y-4">
          {tests.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>Тесттер әлі қосылмаған</p>
              <p className="text-sm mt-2">Жоғарыдағы материалдарды таңдаңыз немесе «Тест қосу» батырмасын басыңыз</p>
            </div>
          ) : (
            tests.map((test, index) => (
              <Card key={test.id} className="p-6 bg-muted/30" data-testid={`test-${index}`}>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-foreground">
                    Тест #{index + 1}
                  </h4>
                  <Button
                    onClick={() => deleteTest(test.id)}
                    variant="ghost"
                    size="icon"
                    data-testid={`button-delete-${index}`}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-2">
                    <Label>Материал атауы</Label>
                    <Input
                      type="text"
                      value={test.materialName}
                      onChange={(e) => updateTest(test.id, "materialName", e.target.value)}
                      placeholder="Мысалы: Темір"
                      data-testid={`input-material-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Магнитке тартылуы</Label>
                    <div className="flex gap-2 h-9">
                      <Button
                        onClick={() => updateTest(test.id, "attracted", true)}
                        variant={test.attracted ? "default" : "outline"}
                        className="flex-1"
                        data-testid={`button-attracted-yes-${index}`}
                      >
                        Тартылады
                      </Button>
                      <Button
                        onClick={() => updateTest(test.id, "attracted", false)}
                        variant={!test.attracted ? "default" : "outline"}
                        className="flex-1"
                        data-testid={`button-attracted-no-${index}`}
                      >
                        Тартылмайды
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Ескертпелер</Label>
                  <Textarea
                    value={test.notes}
                    onChange={(e) => updateTest(test.id, "notes", e.target.value)}
                    placeholder="Бақылау нәтижелері..."
                    className="min-h-[80px]"
                    data-testid={`textarea-notes-${index}`}
                  />
                </div>
              </Card>
            ))
          )}
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4 text-xl">
          Жалпы қорытынды
        </h3>
        <Textarea
          value={generalNotes}
          onChange={(e) => setGeneralNotes(e.target.value)}
          placeholder="Зертхана жұмысы туралы жалпы қорытынды жазыңыз..."
          className="min-h-[150px]"
          data-testid="textarea-general-notes"
        />
      </Card>

      <div className="flex justify-end gap-4">
        <Button
          onClick={saveResults}
          variant="default"
          size="lg"
          disabled={tests.length === 0}
          data-testid="button-save-results"
        >
          <Save className="w-4 h-4 mr-2" />
          Нәтижелерді сақтау
        </Button>
      </div>
    </div>
  );
}
