import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle, RotateCcw, Trophy } from "lucide-react";
import type { QuizQuestion, QuizResult } from "@shared/schema";

interface QuizInterfaceProps {
  labNumber: 7 | 8;
  questions: QuizQuestion[];
}

export default function QuizInterface({ labNumber, questions }: QuizInterfaceProps) {
  const { toast } = useToast();
  const [currentQuestion, setCurrentQuestion] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Map<string, number>>(new Map());
  const [showResults, setShowResults] = useState<boolean>(false);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);

  const question = questions[currentQuestion];
  const totalQuestions = questions.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const handleSelectAnswer = (answerIndex: number) => {
    const newAnswers = new Map(selectedAnswers);
    newAnswers.set(question.id, answerIndex);
    setSelectedAnswers(newAnswers);
    setShowExplanation(false);
  };

  const handleCheckAnswer = () => {
    setShowExplanation(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setShowExplanation(false);
    } else {
      finishQuiz();
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setShowExplanation(false);
    }
  };

  const finishQuiz = () => {
    const answers = questions.map(q => ({
      questionId: q.id,
      selectedAnswer: selectedAnswers.get(q.id) ?? -1,
      correct: selectedAnswers.get(q.id) === q.correctAnswer,
    }));

    const score = answers.filter(a => a.correct).length;

    const result: QuizResult = {
      id: Date.now().toString(),
      labNumber,
      timestamp: Date.now(),
      score,
      totalQuestions,
      answers,
    };

    localStorage.setItem(`quiz-lab${labNumber}-result`, JSON.stringify(result));
    setShowResults(true);

    toast({
      title: "Тест аяқталды!",
      description: `Сіздің нәтижеңіз: ${score} / ${totalQuestions}`,
    });
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswers(new Map());
    setShowResults(false);
    setShowExplanation(false);
  };

  const calculateScore = () => {
    return questions.filter(q => selectedAnswers.get(q.id) === q.correctAnswer).length;
  };

  const selectedAnswer = selectedAnswers.get(question?.id);
  const isCorrect = selectedAnswer === question?.correctAnswer;

  if (showResults) {
    const score = calculateScore();
    const percentage = Math.round((score / totalQuestions) * 100);
    
    let message = "";
    let messageColor = "";
    
    if (percentage >= 90) {
      message = "Өте жақсы! Керемет нәтиже!";
      messageColor = "text-success";
    } else if (percentage >= 70) {
      message = "Жақсы! Бірақ жетілдіруге болады.";
      messageColor = "text-primary";
    } else if (percentage >= 50) {
      message = "Қанағаттанарлық. Материалды қайта қарап шығыңыз.";
      messageColor = "text-warning";
    } else {
      message = "Теорияны қайта оқып, жаттығулар жасаңыз.";
      messageColor = "text-destructive";
    }

    return (
      <div className="space-y-6">
        <Card className="p-8 md:p-12 text-center">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-warning/10 mb-6">
              <Trophy className="w-10 h-10 text-warning" />
            </div>
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Тест нәтижелері
            </h2>
            <p className="text-muted-foreground">
              {labNumber}-зертханалық жұмыс
            </p>
          </div>

          <div className="mb-8">
            <div className="text-6xl font-bold mb-4">
              <span className={messageColor}>{score}</span>
              <span className="text-muted-foreground"> / </span>
              <span className="text-foreground">{totalQuestions}</span>
            </div>
            <div className="text-2xl font-semibold mb-2" data-testid="text-percentage">
              {percentage}%
            </div>
            <p className={`text-lg ${messageColor}`}>{message}</p>
          </div>

          <div className="space-y-4 max-w-md mx-auto">
            <div className="p-4 bg-muted rounded-lg flex justify-between items-center">
              <span className="text-foreground">Дұрыс жауаптар:</span>
              <span className="font-semibold text-success">{score}</span>
            </div>
            <div className="p-4 bg-muted rounded-lg flex justify-between items-center">
              <span className="text-foreground">Қате жауаптар:</span>
              <span className="font-semibold text-destructive">{totalQuestions - score}</span>
            </div>
            <div className="p-4 bg-muted rounded-lg flex justify-between items-center">
              <span className="text-foreground">Барлығы сұрақтар:</span>
              <span className="font-semibold text-foreground">{totalQuestions}</span>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Button onClick={resetQuiz} variant="default" size="lg" data-testid="button-retry">
              <RotateCcw className="w-4 h-4 mr-2" />
              Қайта өту
            </Button>
            <Link href="/">
              <Button variant="outline" size="lg" data-testid="button-home-from-results">
                Басты бетке
              </Button>
            </Link>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 text-xl">
            Жауаптардың толық тізімі
          </h3>
          <div className="space-y-3">
            {questions.map((q, index) => {
              const userAnswer = selectedAnswers.get(q.id);
              const isCorrect = userAnswer === q.correctAnswer;
              
              return (
                <div
                  key={q.id}
                  className={`p-4 rounded-lg border ${
                    isCorrect
                      ? "bg-success/5 border-success/20"
                      : "bg-destructive/5 border-destructive/20"
                  }`}
                  data-testid={`result-${index}`}
                >
                  <div className="flex items-start gap-3">
                    {isCorrect ? (
                      <CheckCircle className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium text-foreground mb-2">
                        {index + 1}. {q.question}
                      </p>
                      {!isCorrect && (
                        <p className="text-sm text-muted-foreground">
                          Дұрыс жауап: {q.options[q.correctAnswer]}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    );
  }

  if (!question) {
    return (
      <Card className="p-12 text-center">
        <p className="text-muted-foreground">Сұрақтар жүктелуде...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-muted-foreground">
            Сұрақ {currentQuestion + 1} / {totalQuestions}
          </span>
          <span className="text-sm font-medium text-foreground">
            {Math.round(progress)}%
          </span>
        </div>
        <Progress value={progress} className="h-2" />
      </Card>

      <Card className="p-8 md:p-12">
        <div className="mb-8">
          <h3 className="text-2xl font-semibold text-foreground mb-2">
            Сұрақ #{currentQuestion + 1}
          </h3>
          <p className="text-xl text-foreground leading-relaxed" data-testid="text-question">
            {question.question}
          </p>
        </div>

        <RadioGroup
          value={selectedAnswer?.toString()}
          onValueChange={(value) => handleSelectAnswer(parseInt(value))}
        >
          <div className="space-y-4">
            {question.options.map((option, index) => (
              <div
                key={index}
                className={`flex items-center space-x-3 p-4 rounded-lg border-2 transition-all ${
                  selectedAnswer === index
                    ? showExplanation
                      ? index === question.correctAnswer
                        ? "border-success bg-success/5"
                        : "border-destructive bg-destructive/5"
                      : "border-primary bg-primary/5"
                    : "border-border bg-card hover-elevate"
                }`}
                data-testid={`option-${index}`}
              >
                <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                <Label
                  htmlFor={`option-${index}`}
                  className="flex-1 cursor-pointer text-foreground"
                >
                  {option}
                </Label>
                {showExplanation && index === question.correctAnswer && (
                  <CheckCircle className="w-5 h-5 text-success" />
                )}
                {showExplanation && selectedAnswer === index && index !== question.correctAnswer && (
                  <XCircle className="w-5 h-5 text-destructive" />
                )}
              </div>
            ))}
          </div>
        </RadioGroup>

        {showExplanation && (
          <Card className={`mt-6 p-6 ${
            isCorrect ? "bg-success/5 border-success/20" : "bg-warning/5 border-warning/20"
          }`}>
            <div className="flex items-start gap-3">
              {isCorrect ? (
                <CheckCircle className="w-6 h-6 text-success mt-0.5 flex-shrink-0" />
              ) : (
                <XCircle className="w-6 h-6 text-warning mt-0.5 flex-shrink-0" />
              )}
              <div>
                <h4 className="font-semibold text-foreground mb-2">
                  {isCorrect ? "Дұрыс!" : "Қате жауап"}
                </h4>
                <p className="text-foreground leading-relaxed" data-testid="text-explanation">
                  {question.explanation}
                </p>
              </div>
            </div>
          </Card>
        )}

        <div className="mt-8 flex flex-wrap gap-4 justify-between">
          <Button
            onClick={handlePreviousQuestion}
            variant="outline"
            disabled={currentQuestion === 0}
            data-testid="button-previous"
          >
            Артқа
          </Button>

          <div className="flex gap-4">
            {!showExplanation && selectedAnswer !== undefined && (
              <Button
                onClick={handleCheckAnswer}
                variant="secondary"
                data-testid="button-check"
              >
                Тексеру
              </Button>
            )}
            
            {showExplanation && (
              <Button
                onClick={handleNextQuestion}
                variant="default"
                data-testid="button-next"
              >
                {currentQuestion === totalQuestions - 1 ? "Аяқтау" : "Келесі"}
                <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Button>
            )}
          </div>
        </div>
      </Card>

      <Card className="p-6 bg-muted/30">
        <p className="text-sm text-muted-foreground text-center">
          Жауапты таңдап, «Тексеру» батырмасын басыңыз
        </p>
      </Card>
    </div>
  );
}
