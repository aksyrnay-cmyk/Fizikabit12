import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Battery, Gauge, Zap, RotateCcw, Lightbulb } from "lucide-react";

interface CircuitElement {
  id: string;
  type: "battery" | "ammeter" | "voltmeter" | "lamp" | "switch";
  x: number;
  y: number;
  placed: boolean;
}

export default function ElectricCircuitSimulation() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [voltage, setVoltage] = useState<number>(6);
  const [current, setCurrent] = useState<number>(2);
  const [time, setTime] = useState<number>(5);
  const [power, setPower] = useState<number>(0);
  const [work, setWork] = useState<number>(0);
  const [circuitActive, setCircuitActive] = useState<boolean>(false);
  const [draggedElement, setDraggedElement] = useState<CircuitElement | null>(null);

  const [elements, setElements] = useState<CircuitElement[]>([
    { id: "battery", type: "battery", x: 50, y: 50, placed: false },
    { id: "ammeter", type: "ammeter", x: 50, y: 130, placed: false },
    { id: "voltmeter", type: "voltmeter", x: 50, y: 210, placed: false },
    { id: "lamp", type: "lamp", x: 50, y: 290, placed: false },
    { id: "switch", type: "switch", x: 50, y: 370, placed: false },
  ]);

  useEffect(() => {
    const p = voltage * current;
    const a = p * time;
    setPower(p);
    setWork(a);
  }, [voltage, current, time]);

  useEffect(() => {
    drawCircuit();
  }, [circuitActive, voltage, current, elements]);

  const drawCircuit = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = 120;

    ctx.strokeStyle = circuitActive ? "hsl(210, 90%, 50%)" : "hsl(0, 0%, 60%)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.stroke();

    if (circuitActive) {
      ctx.fillStyle = "hsl(210, 90%, 50%)";
      ctx.font = "24px JetBrains Mono";
      ctx.textAlign = "center";
      ctx.fillText(`${voltage}V`, centerX, centerY - radius - 20);
      ctx.fillText(`${current}A`, centerX + radius + 40, centerY);
      
      const lampX = centerX;
      const lampY = centerY + radius + 40;
      const brightness = Math.min((voltage * current) / 20, 1);
      const gradient = ctx.createRadialGradient(lampX, lampY, 0, lampX, lampY, 30);
      gradient.addColorStop(0, `hsla(38, 92%, 50%, ${brightness})`);
      gradient.addColorStop(1, `hsla(38, 92%, 50%, 0)`);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(lampX, lampY, 30, 0, Math.PI * 2);
      ctx.fill();
    }

    elements.forEach((el) => {
      if (el.placed) {
        ctx.fillStyle = "hsl(142, 76%, 36%)";
        ctx.fillRect(el.x, el.y, 40, 40);
      }
    });
  };

  const handleDragStart = (element: CircuitElement) => {
    setDraggedElement(element);
  };

  const handleDragOver = (e: React.DragEvent<HTMLCanvasElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (draggedElement && canvasRef.current) {
      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const newElements = elements.map(el => 
        el.id === draggedElement.id 
          ? { ...el, x, y, placed: true }
          : el
      );
      
      setElements(newElements);
      setDraggedElement(null);
    }
  };

  const toggleCircuit = () => {
    setCircuitActive(!circuitActive);
  };

  const resetCircuit = () => {
    setCircuitActive(false);
    setVoltage(6);
    setCurrent(2);
    setTime(5);
    setElements([
      { id: "battery", type: "battery", x: 50, y: 50, placed: false },
      { id: "ammeter", type: "ammeter", x: 50, y: 130, placed: false },
      { id: "voltmeter", type: "voltmeter", x: 50, y: 210, placed: false },
      { id: "lamp", type: "lamp", x: 50, y: 290, placed: false },
      { id: "switch", type: "switch", x: 50, y: 370, placed: false },
    ]);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary" />
                Электр тізбегінің элементтері
              </h3>
              <div className="space-y-3">
                {elements.map((element) => (
                  <div
                    key={element.id}
                    draggable
                    onDragStart={() => handleDragStart(element)}
                    onDragEnd={handleDrop}
                    className="flex items-center gap-3 p-3 bg-background rounded-md border border-border cursor-move hover-elevate active-elevate-2"
                    data-testid={`element-${element.type}`}
                  >
                    {element.type === "battery" && <Battery className="w-6 h-6 text-primary" />}
                    {element.type === "ammeter" && <Gauge className="w-6 h-6 text-success" />}
                    {element.type === "voltmeter" && <Gauge className="w-6 h-6 text-warning" />}
                    {element.type === "lamp" && <Lightbulb className="w-6 h-6 text-energy" />}
                    {element.type === "switch" && <Zap className="w-6 h-6 text-muted-foreground" />}
                    <span className="text-sm text-foreground">
                      {element.type === "battery" && "Ток көзі"}
                      {element.type === "ammeter" && "Амперметр"}
                      {element.type === "voltmeter" && "Вольтметр"}
                      {element.type === "lamp" && "Қыздыру шамы"}
                      {element.type === "switch" && "Кілт"}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={toggleCircuit}
                variant={circuitActive ? "destructive" : "default"}
                className="flex-1"
                data-testid="button-toggle-circuit"
              >
                {circuitActive ? "Тізбекті өшіру" : "Тізбекті іске қосу"}
              </Button>
              <Button
                onClick={resetCircuit}
                variant="outline"
                size="icon"
                data-testid="button-reset-circuit"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex-1">
            <div className="border-2 border-dashed border-border rounded-lg p-4 bg-muted/20 min-h-[400px] flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={500}
                height={400}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className="max-w-full"
                data-testid="canvas-circuit"
              />
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-6 text-xl">
          Өлшеу мен есептеу
        </h3>
        
        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <div className="space-y-2">
            <Label htmlFor="voltage-input">Кернеу (U), Вольт</Label>
            <Input
              id="voltage-input"
              type="number"
              value={voltage}
              onChange={(e) => setVoltage(Number(e.target.value))}
              min="0"
              max="24"
              step="0.1"
              className="font-mono"
              data-testid="input-voltage"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="current-input">Ток күші (I), Ампер</Label>
            <Input
              id="current-input"
              type="number"
              value={current}
              onChange={(e) => setCurrent(Number(e.target.value))}
              min="0"
              max="10"
              step="0.1"
              className="font-mono"
              data-testid="input-current"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="time-input">Уақыт (t), секунд</Label>
            <Input
              id="time-input"
              type="number"
              value={time}
              onChange={(e) => setTime(Number(e.target.value))}
              min="0"
              max="3600"
              step="1"
              className="font-mono"
              data-testid="input-time"
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-6 bg-primary/5 border-primary/20">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Қуат (P = I × U)</p>
              <p className="text-4xl font-bold font-mono text-primary" data-testid="text-power">
                {power.toFixed(2)} <span className="text-2xl">Вт</span>
              </p>
            </div>
          </Card>

          <Card className="p-6 bg-energy/5 border-energy/20">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Жұмыс (A = P × t)</p>
              <p className="text-4xl font-bold font-mono text-energy" data-testid="text-work">
                {work.toFixed(2)} <span className="text-2xl">Дж</span>
              </p>
            </div>
          </Card>
        </div>

        <div className="mt-6 p-4 bg-success/5 border border-success/20 rounded-lg">
          <p className="text-sm text-foreground">
            <strong>Формулалар:</strong> P = I · U = {voltage} · {current} = {power.toFixed(2)} Вт, 
            A = P · t = {power.toFixed(2)} · {time} = {work.toFixed(2)} Дж
          </p>
        </div>
      </Card>
    </div>
  );
}
