import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Magnet, RotateCcw } from "lucide-react";

interface Material {
  name: string;
  type: "ferromagnetic" | "paramagnetic" | "diamagnetic";
  attracted: boolean;
}

export default function MagneticFieldSimulation() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [magnetX, setMagnetX] = useState<number>(250);
  const [magnetY, setMagnetY] = useState<number>(200);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);

  const materials: Material[] = [
    { name: "Темір", type: "ferromagnetic", attracted: true },
    { name: "Никель", type: "ferromagnetic", attracted: true },
    { name: "Болат", type: "ferromagnetic", attracted: true },
    { name: "Алюминий", type: "paramagnetic", attracted: false },
    { name: "Мыс", type: "diamagnetic", attracted: false },
    { name: "Пластик", type: "diamagnetic", attracted: false },
    { name: "Ағаш", type: "diamagnetic", attracted: false },
    { name: "Қағаз", type: "diamagnetic", attracted: false },
  ];

  useEffect(() => {
    drawMagneticField();
  }, [magnetX, magnetY, selectedMaterial]);

  const drawMagneticField = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawFieldLines(ctx, magnetX, magnetY);
    
    drawMagnet(ctx, magnetX, magnetY);

    if (selectedMaterial) {
      const materialX = magnetX + 150;
      const materialY = magnetY;
      drawMaterial(ctx, materialX, materialY, selectedMaterial);
      
      if (selectedMaterial.attracted) {
        drawAttractionEffect(ctx, magnetX, magnetY, materialX, materialY);
      }
    }

    drawIronFilings(ctx, magnetX, magnetY);
  };

  const drawFieldLines = (ctx: CanvasRenderingContext2D, mx: number, my: number) => {
    ctx.strokeStyle = "hsl(0, 85%, 55%)";
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);

    const numLines = 8;
    for (let i = 0; i < numLines; i++) {
      const angle = (Math.PI * 2 * i) / numLines;
      const radius = 80;
      
      ctx.beginPath();
      const startX = mx + Math.cos(angle) * 30;
      const startY = my + Math.sin(angle) * 30;
      const endX = mx + Math.cos(angle) * radius;
      const endY = my + Math.sin(angle) * radius;
      
      const controlX = mx + Math.cos(angle + 0.5) * radius * 0.7;
      const controlY = my + Math.sin(angle + 0.5) * radius * 0.7;
      
      ctx.moveTo(startX, startY);
      ctx.quadraticCurveTo(controlX, controlY, endX, endY);
      ctx.stroke();
    }
    
    ctx.setLineDash([]);
  };

  const drawMagnet = (ctx: CanvasRenderingContext2D, x: number, y: number) => {
    const width = 80;
    const height = 40;
    
    ctx.fillStyle = "hsl(0, 85%, 55%)";
    ctx.fillRect(x - width / 2, y - height / 2, width / 2, height);
    
    ctx.fillStyle = "hsl(210, 90%, 50%)";
    ctx.fillRect(x, y - height / 2, width / 2, height);
    
    ctx.fillStyle = "white";
    ctx.font = "bold 16px Inter";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("S", x - width / 4, y);
    ctx.fillText("N", x + width / 4, y);
    
    ctx.strokeStyle = "hsl(0, 0%, 20%)";
    ctx.lineWidth = 2;
    ctx.strokeRect(x - width / 2, y - height / 2, width, height);
  };

  const drawMaterial = (ctx: CanvasRenderingContext2D, x: number, y: number, material: Material) => {
    const colors = {
      ferromagnetic: "hsl(142, 76%, 36%)",
      paramagnetic: "hsl(38, 92%, 50%)",
      diamagnetic: "hsl(0, 0%, 60%)",
    };
    
    ctx.fillStyle = colors[material.type];
    ctx.beginPath();
    ctx.arc(x, y, 20, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.strokeStyle = "hsl(0, 0%, 20%)";
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  const drawAttractionEffect = (
    ctx: CanvasRenderingContext2D,
    mx: number,
    my: number,
    matX: number,
    matY: number
  ) => {
    ctx.strokeStyle = "hsl(142, 76%, 36%)";
    ctx.lineWidth = 3;
    ctx.setLineDash([10, 5]);
    
    ctx.beginPath();
    ctx.moveTo(mx + 40, my);
    ctx.lineTo(matX - 25, matY);
    ctx.stroke();
    
    ctx.setLineDash([]);
    
    const arrowSize = 8;
    const angle = Math.atan2(matY - my, matX - mx);
    const arrowX = matX - 25;
    const arrowY = matY;
    
    ctx.fillStyle = "hsl(142, 76%, 36%)";
    ctx.beginPath();
    ctx.moveTo(arrowX, arrowY);
    ctx.lineTo(
      arrowX - arrowSize * Math.cos(angle - Math.PI / 6),
      arrowY - arrowSize * Math.sin(angle - Math.PI / 6)
    );
    ctx.lineTo(
      arrowX - arrowSize * Math.cos(angle + Math.PI / 6),
      arrowY - arrowSize * Math.sin(angle + Math.PI / 6)
    );
    ctx.closePath();
    ctx.fill();
  };

  const drawIronFilings = (ctx: CanvasRenderingContext2D, mx: number, my: number) => {
    ctx.fillStyle = "hsl(0, 0%, 40%)";
    
    for (let i = 0; i < 100; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = 30 + Math.random() * 70;
      const x = mx + Math.cos(angle) * radius;
      const y = my + Math.sin(angle) * radius;
      
      const particleAngle = angle + Math.PI / 2 + (Math.random() - 0.5) * 0.5;
      const length = 3 + Math.random() * 3;
      
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(particleAngle);
      ctx.fillRect(-length / 2, -0.5, length, 1);
      ctx.restore();
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const distance = Math.sqrt((x - magnetX) ** 2 + (y - magnetY) ** 2);
    if (distance < 50) {
      setIsDragging(true);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setMagnetX(Math.max(50, Math.min(450, x)));
    setMagnetY(Math.max(50, Math.min(350, y)));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const resetSimulation = () => {
    setMagnetX(250);
    setMagnetY(200);
    setSelectedMaterial(null);
  };

  const testMaterial = (material: Material) => {
    setSelectedMaterial(material);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Magnet className="w-5 h-5 text-energy" />
                Материалдарды тексеру
              </h3>
              <div className="space-y-2">
                {materials.map((material) => (
                  <Button
                    key={material.name}
                    onClick={() => testMaterial(material)}
                    variant={selectedMaterial?.name === material.name ? "default" : "outline"}
                    className="w-full justify-start"
                    data-testid={`button-material-${material.name}`}
                  >
                    <span className="flex-1 text-left">{material.name}</span>
                    <Badge
                      variant={material.attracted ? "default" : "secondary"}
                      className="ml-2"
                    >
                      {material.attracted ? "Тартылады" : "Тартылмайды"}
                    </Badge>
                  </Button>
                ))}
              </div>
            </div>

            <Button
              onClick={resetSimulation}
              variant="outline"
              className="w-full"
              data-testid="button-reset-magnet"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Қайта бастау
            </Button>
          </div>

          <div className="flex-1">
            <div className="border-2 border-dashed border-border rounded-lg p-4 bg-muted/20 min-h-[400px]">
              <p className="text-sm text-muted-foreground mb-3 text-center">
                Магнитті сүйреп қозғалтыңыз
              </p>
              <canvas
                ref={canvasRef}
                width={500}
                height={400}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                className="max-w-full cursor-move"
                data-testid="canvas-magnet"
              />
            </div>
          </div>
        </div>
      </Card>

      {selectedMaterial && (
        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 text-xl">
            Нәтижелер: {selectedMaterial.name}
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">Материал түрі</p>
              <p className="font-semibold text-foreground">
                {selectedMaterial.type === "ferromagnetic" && "Ферромагнетик"}
                {selectedMaterial.type === "paramagnetic" && "Парамагнетик"}
                {selectedMaterial.type === "diamagnetic" && "Диамагнетик"}
              </p>
            </div>

            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">Магнитке тартылуы</p>
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${
                    selectedMaterial.attracted ? "bg-success" : "bg-destructive"
                  }`}
                />
                <p className="font-semibold text-foreground">
                  {selectedMaterial.attracted ? "Тартылады" : "Тартылмайды"}
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-primary/5 border border-primary/20 rounded-lg">
            <p className="text-sm text-foreground">
              <strong>Түсіндірме:</strong>{" "}
              {selectedMaterial.type === "ferromagnetic" &&
                "Ферромагнетиктер күшті магниттік қасиеттері бар заттар. Олар магнитке күшті тартылады."}
              {selectedMaterial.type === "paramagnetic" &&
                "Парамагнетиктер магнитке әлсіз тартылатын заттар. Олардың магниттік қасиеттері өте әлсіз."}
              {selectedMaterial.type === "diamagnetic" &&
                "Диамагнетиктер магниттен итерілетін заттар. Олар магниттік қасиеттерге ие емес."}
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
